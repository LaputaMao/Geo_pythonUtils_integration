# -*- coding: utf-8 -*-
import sys
import os
from natcap.invest import carbon
import tkinter as tk
from tkinter import messagebox


def run_carbon_model(workspace_dir, lulc_cur_path, lulc_fut_path, lulc_redd_path, carbon_pools_path, do_redd, calc_sequestration, status_label, root):
    # 定义模型参数
    args = {
        'workspace_dir': workspace_dir,
        'results_suffix': '',
        'lulc_cur_path': lulc_cur_path,
        'lulc_fut_path': lulc_fut_path,
        'lulc_redd_path': lulc_redd_path,
        'carbon_pools_path': carbon_pools_path,
        'do_redd': do_redd,
        'calc_sequestration': calc_sequestration,
    }

    # 删除值为 None 的可选参数
    args = {k: v for k, v in args.items() if v is not None}

    # 创建工作目录
    if not os.path.exists(workspace_dir):
        os.makedirs(workspace_dir)

    try:
        # 显示状态提示
        status_label.config(text="模型正在运行，请稍候...")
        root.update_idletasks()

        # 运行模型
        carbon.execute(args)

        # 显示完成提示
        messagebox.showinfo("运行完成", "碳储量模型运行完成。")
    except Exception as e:
        messagebox.showerror("运行错误", f"模型运行出错: {str(e)}")
    finally:
        # 关闭状态提示窗口
        root.destroy()

if __name__ == "__main__":
    # 初始化Tkinter根窗口
    root = tk.Tk()
    root.title("模型运行状态")
    root.geometry("300x100")

    # 创建一个简单的状态标签
    status_label = tk.Label(root, text="准备运行模型...")
    status_label.pack(pady=20)

    # 从命令行获取参数
    if len(sys.argv) != 8:
        messagebox.showerror("参数错误", "用法: python carbon_storage.py <workspace_dir> <lulc_cur_path> <lulc_fut_path> <lulc_redd_path> <carbon_pools_path> <do_redd> <calc_sequestration>")
        sys.exit(1)

    workspace_dir = sys.argv[1]
    lulc_cur_path = sys.argv[2]
    lulc_fut_path = sys.argv[3] if sys.argv[3] != 'None' else None
    lulc_redd_path = sys.argv[4] if sys.argv[4] != 'None' else None
    carbon_pools_path = sys.argv[5]
    do_redd = sys.argv[6].lower() == 'true'
    calc_sequestration = sys.argv[7].lower() == 'true'

    # 运行模型并显示状态
    root.after(100, run_carbon_model, workspace_dir, lulc_cur_path, lulc_fut_path, lulc_redd_path, carbon_pools_path, do_redd, calc_sequestration, status_label, root)
    root.mainloop()
